#pragma once

class Vertex;
class Edge;
class Face;
class Shape;